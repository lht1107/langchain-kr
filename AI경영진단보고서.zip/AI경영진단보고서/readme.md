project/
├── main.py # FastAPI 엔드포인트를 정의하고 실행하는 메인 파일
├── overview_table.csv # 데이터 개요 테이블
├── analysis/ # 분석 관련 모듈
│ ├── **init**.py # analysis 모듈 초기화
│ ├── create_analysis_chain.py # 분석 체인 생성 함수
│ ├── create_summary_chain.py # 요약 체인 생성 함수
│ ├── determine_strength_weakness.py # 강점 및 약점 결정 함수
│ └── merge_analysis_results.py # 분석 결과 병합 함수
├── api/ # API 관련 모듈
│ ├── routes/ # API 라우트
│ │ ├── **init**.py # API routes 모듈 초기화
│ │ ├── analysis.py # 분석 관련 API 엔드포인트
│ │ ├── health.py # 시스템 상태 확인 API 엔드포인트
│ │ └── query.py # 쿼리 관련 API 엔드포인트
├── core/ # 핵심 기능 관련 모듈
│ ├── **init**.py # core 모듈 초기화
│ ├── cache.py # 캐싱 관련 함수
│ ├── config.py # 환경 변수 및 설정 관리
│ ├── dependencies.py # 의존성 관리
│ ├── exceptions.py # 예외 처리 정의
│ ├── middleware.py # 미들웨어 정의
│ └── server.py # 서버 설정 및 실행 관리
├── database/ # 데이터베이스 관련 모듈
│ ├── **init**.py # database 모듈 초기화
│ ├── base.py # 데이터베이스 베이스 모델
│ ├── f_read_pg_sql.py # PostgreSQL 데이터 조회 함수
│ ├── f_read_pg_sql_original.py # PostgreSQL 데이터 조회 함수 (원본)
│ ├── generate_sql_query.py # SQL 쿼리 생성 함수
│ ├── postgresql_cache.py # PostgreSQL 캐싱
│ ├── redis_cache.py # Redis 캐싱
│ ├── sqlite_cache.py # SQLite 캐싱
│ └── sqlite_cache.db # SQLite 캐싱 데이터베이스
├── preprocessing/ # 데이터 전처리 관련 모듈
│ ├── **init**.py # preprocessing 모듈 초기화
│ ├── preprocess_financial_stability_data.py # 재무 안정성 데이터 전처리
│ ├── preprocess_growth_data.py # 성장성 데이터 전처리
│ ├── preprocess_partner_stability_data.py # 파트너 안정성 데이터 전처리
│ └── preprocess_profitability_data.py # 수익성 데이터 전처리
├── prompts/ # 분석 템플릿 관련 파일
│ ├── growth_template.txt # 성장성 분석 템플릿
│ ├── insight_template.txt # 인사이트 분석 템플릿
│ ├── partner_stability_template.txt # 파트너 안정성 분석 템플릿
│ ├── profitability_template.txt # 수익성 분석 템플릿
│ └── summary_template.txt # 요약 분석 템플릿
├── streamlit/ # Streamlit 애플리케이션 관련 파일
│ ├── app.py # Streamlit 애플리케이션
│ └── overview_table.csv # Streamlit용 데이터 개요 테이블
├── utils/ # 유틸리티 함수 관련 모듈
│ ├── **init**.py # utils 모듈 초기화
│ ├── cache_utils.py # 캐시 유틸리티 함수
│ ├── generate_sample_data.py # 샘플 데이터 생성 함수
│ ├── load_prompt.py # 템플릿 파일 로드 함수
│ ├── logger.py # 로깅 설정 및 유틸리티
│ ├── time_utils.py # 시간 및 날짜 유틸리티 함수
│ └── validation.py # 데이터 검증 유틸리티 함수
├── logs/ # 로그 파일 저장 디렉터리
