# 기본 모듈
import sqlite3
import json
from typing import Dict, Optional
from datetime import datetime

# 비동기 지원
import aiosqlite

# 내부 모듈
from core.config import settings
from database.base import BaseCache
from utils.logger import get_logger

logger = get_logger(__name__)


class SQLiteCache(BaseCache):
    """SQLite 기반 캐시 구현"""

    def __init__(self):
        self.db_path = settings.SQLITE_DB_PATH
        self._init_db()

    def _init_db(self):
        """캐시 테이블 초기화"""
        with sqlite3.connect(self.db_path) as conn:
            # 분석 결과 테이블
            conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {settings.SQLITE_TABLE_NAME} (
                    cache_key TEXT PRIMARY KEY,
                    strength_indicator TEXT,
                    strength_detailed TEXT,
                    strength_summary TEXT,
                    weakness_indicator TEXT,
                    weakness_detailed TEXT,
                    weakness_summary TEXT,
                    insight_indicator TEXT,
                    insight_summary TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # 피드백 테이블
            conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {settings.SQLITE_FEEDBACK_NAME} (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    company_name TEXT NOT NULL,
                    feedback_type TEXT NOT NULL,
                    feedback_text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            # 캐시 키 인덱스 추가
            conn.execute(f"""
                CREATE INDEX IF NOT EXISTS {settings.SQLITE_CACHE_INDEX} 
                ON {settings.SQLITE_TABLE_NAME}(cache_key)
            """)

    async def get(self, key: str) -> Optional[Dict]:
        """캐시 데이터 조회"""
        try:
            today = datetime.now()
            company_name = key.split(':')[0]
            current_month = f"{today.year}-{today.month:02d}"

            async with aiosqlite.connect(self.db_path) as conn:
                # THRESHOLD 이후인 경우 해당 월의 THRESHOLD 이후 데이터만 조회
                if today.day >= settings.THRESHOLD:
                    async with conn.execute(
                        f"""SELECT 
                            strength_indicator, strength_detailed, strength_summary,
                            weakness_indicator, weakness_detailed, weakness_summary,
                            insight_indicator, insight_summary,
                            created_at
                        FROM {settings.SQLITE_TABLE_NAME} 
                        WHERE cache_key LIKE ? 
                        AND strftime('%d', created_at) >= ?
                        ORDER BY created_at DESC 
                        LIMIT 1""",
                        (f"{company_name}:{current_month}-%",
                         f"{settings.THRESHOLD:02d}")
                    ) as cursor:
                        row = await cursor.fetchone()
                else:
                    # THRESHOLD 이전에는 해당 월의 모든 데이터 중 최신 데이터 조회
                    async with conn.execute(
                        f"""SELECT 
                            strength_indicator, strength_detailed, strength_summary,
                            weakness_indicator, weakness_detailed, weakness_summary,
                            insight_indicator, insight_summary,
                            created_at
                        FROM {settings.SQLITE_TABLE_NAME} 
                        WHERE cache_key LIKE ? 
                        ORDER BY created_at DESC 
                        LIMIT 1""",
                        (f"{company_name}:{current_month}-%",)
                    ) as cursor:
                        row = await cursor.fetchone()

                if not row:
                    return None

                return {
                    'strength': {
                        'indicator': row[0],
                        'detailed_analysis': row[1],
                        'summary': row[2]
                    },
                    'weakness': {
                        'indicator': row[3],
                        'detailed_analysis': row[4],
                        'summary': row[5]
                    },
                    'insight': {
                        'indicator': row[6],
                        'summary': row[7]
                    }
                }

        except Exception as e:
            logger.error(f"SQLite get error: {str(e)}")
            return None

    async def set(self, key: str, value: Dict) -> None:
        """캐시 데이터 저장"""
        try:
            async with aiosqlite.connect(self.db_path) as conn:
                await conn.execute("BEGIN TRANSACTION")
                try:
                    # 분석 결과 저장
                    await conn.execute(
                        f"""INSERT OR REPLACE INTO {settings.SQLITE_TABLE_NAME} 
                        (cache_key, 
                         strength_indicator, strength_detailed, strength_summary,
                         weakness_indicator, weakness_detailed, weakness_summary,
                         insight_indicator, insight_summary) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (key,
                         value['strength'].get('indicator'),
                         value['strength'].get('detailed_analysis'),
                         value['strength'].get('summary'),
                         value['weakness'].get('indicator'),
                         value['weakness'].get('detailed_analysis'),
                         value['weakness'].get('summary'),
                         value['insight'].get('indicator'),
                         value['insight'].get('summary'))
                    )

                    await conn.commit()
                    logger.debug(
                        f"[SQLite] Successfully stored data for key: {key}")

                except Exception as e:
                    await conn.rollback()
                    logger.error(f"[SQLite] Transaction failed: {str(e)}")
                    raise e

        except Exception as e:
            logger.error(f"SQLite Connection error: {str(e)}")

    async def close(self) -> None:
        """연결 종료 (컨텍스트 매니저로 관리되므로 별도 처리 불필요)"""
        pass
