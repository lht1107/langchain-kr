# postgresql_cache.py
from typing import Dict, Optional
import asyncpg
from tenacity import retry, stop_after_attempt, wait_exponential

from core.config import settings
from database.base import BaseCache
from utils.logger import get_logger
from datetime import datetime

logger = get_logger(__name__)


class PostgreSQLCache(BaseCache):
    """PostgreSQL 기반 캐시 구현

    캐시 데이터를 PostgreSQL에 저장하고 관리하는 클래스입니다.
    SQLite와 동일한 테이블 구조를 사용하여 일관성을 유지합니다.

    Attributes:
        _pool: 데이터베이스 연결 풀
        settings: 애플리케이션 설정
    """

    def __init__(self):
        """PostgreSQL 캐시 초기화"""
        self._pool = None
        self.settings = settings

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True,
        before_sleep=lambda retry_state: logger.warning(
            f"[PostgreSQL] Connection retry attempt {retry_state.attempt_number}"
        )
    )
    async def _get_pool(self) -> asyncpg.Pool:
        """커넥션 풀 생성 또는 반환

        Returns:
            asyncpg.Pool: PostgreSQL 연결 풀

        Notes:
            - min_size=5: 최소 연결 수 유지로 빠른 응답 보장
            - max_size=20: 최대 연결 수 제한으로 리소스 관리
        """
        if not self._pool:
            self._pool = await asyncpg.create_pool(
                self.settings.CONNECTION_STRING,
                min_size=5,
                max_size=20
            )
            await self._init_db()
        return self._pool

    async def _init_db(self):
        """캐시 테이블 초기화

        Notes:
            - SQLite와 동일한 테이블 구조 사용
            - 캐시 키에 대한 인덱스 생성으로 조회 성능 최적화
        """
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            # 분석 결과 테이블 생성
            await conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {settings.SQLITE_TABLE_NAME} (
                    cache_key TEXT PRIMARY KEY,
                    strength_indicator TEXT,
                    strength_detailed TEXT,
                    strength_summary TEXT,
                    weakness_indicator TEXT,
                    weakness_detailed TEXT,
                    weakness_summary TEXT,
                    insight_indicator TEXT,
                    insight_summary TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # 피드백 테이블 생성
            await conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {settings.SQLITE_FEEDBACK_NAME} (
                    id SERIAL PRIMARY KEY,
                    company_name TEXT NOT NULL,
                    feedback_type TEXT NOT NULL,
                    feedback_text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # 캐시 키 인덱스 추가
            await conn.execute(f"""
                CREATE INDEX IF NOT EXISTS {settings.SQLITE_CACHE_INDEX} 
                ON {settings.SQLITE_TABLE_NAME}(cache_key)
                WHERE cache_key IS NOT NULL
            """)

    async def get(self, key: str) -> Optional[Dict]:
        """캐시 데이터 조회"""
        try:
            today = datetime.now()
            company_name = key.split(':')[0]
            current_month = f"{today.year}-{today.month:02d}"

            pool = await self._get_pool()
            async with pool.acquire() as conn:
                # THRESHOLD 이후인 경우 해당 월의 THRESHOLD 이후 데이터만 조회
                if today.day >= settings.THRESHOLD:
                    row = await conn.fetchrow(
                        f"""SELECT 
                            strength_indicator, strength_detailed, strength_summary,
                            weakness_indicator, weakness_detailed, weakness_summary,
                            insight_indicator, insight_summary,
                            created_at
                        FROM {settings.SQLITE_TABLE_NAME} 
                        WHERE cache_key LIKE $1 
                        AND EXTRACT(DAY FROM created_at) >= $2
                        ORDER BY created_at DESC 
                        LIMIT 1""",
                        f"{company_name}:{current_month}-%",
                        settings.THRESHOLD
                    )
                else:
                    # THRESHOLD 이전에는 해당 월의 모든 데이터 중 최신 데이터 조회
                    row = await conn.fetchrow(
                        f"""SELECT 
                            strength_indicator, strength_detailed, strength_summary,
                            weakness_indicator, weakness_detailed, weakness_summary,
                            insight_indicator, insight_summary,
                            created_at
                        FROM {settings.SQLITE_TABLE_NAME} 
                        WHERE cache_key LIKE $1 
                        ORDER BY created_at DESC 
                        LIMIT 1""",
                        f"{company_name}:{current_month}-%"
                    )

                if not row:
                    return None

                return {
                    'strength': {
                        'indicator': row['strength_indicator'],
                        'detailed_analysis': row['strength_detailed'],
                        'summary': row['strength_summary']
                    },
                    'weakness': {
                        'indicator': row['weakness_indicator'],
                        'detailed_analysis': row['weakness_detailed'],
                        'summary': row['weakness_summary']
                    },
                    'insight': {
                        'indicator': row['insight_indicator'],
                        'summary': row['insight_summary']
                    }
                }

        except Exception as e:
            logger.error(f"[PostgreSQL] Get error for key {key}: {str(e)}")
            return None

    async def set(self, key: str, value: Dict) -> None:
        """캐시 데이터 저장

        Args:
            key: 캐시 키
            value: 저장할 분석 결과 데이터
        """
        try:
            pool = await self._get_pool()
            async with pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute(
                        f"""INSERT INTO {settings.SQLITE_TABLE_NAME} 
                        (cache_key, 
                         strength_indicator, strength_detailed, strength_summary,
                         weakness_indicator, weakness_detailed, weakness_summary,
                         insight_indicator, insight_summary) 
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                        ON CONFLICT (cache_key) DO UPDATE SET
                            strength_indicator = $2,
                            strength_detailed = $3,
                            strength_summary = $4,
                            weakness_indicator = $5,
                            weakness_detailed = $6,
                            weakness_summary = $7,
                            insight_indicator = $8,
                            insight_summary = $9,
                            created_at = CURRENT_TIMESTAMP""",
                        key,
                        value['strength'].get('indicator'),
                        value['strength'].get('detailed_analysis'),
                        value['strength'].get('summary'),
                        value['weakness'].get('indicator'),
                        value['weakness'].get('detailed_analysis'),
                        value['weakness'].get('summary'),
                        value['insight'].get('indicator'),
                        value['insight'].get('summary')
                    )
                    logger.debug(
                        f"[PostgreSQL] Successfully stored data for key: {key}")

        except Exception as e:
            logger.error(f"[PostgreSQL] Set error for key {key}: {str(e)}")

    async def close(self):
        """커넥션 풀 종료"""
        if self._pool:
            await self._pool.close()
            self._pool = None
            logger.info("[PostgreSQL] Connection pool closed")
